To open the website, do the following:
1. Copy the 'website' folder into the www directory of the Wamp Server or the XAMPP.
2. To browse the content of the website, open the browser and then type 'localhost/website' in the address bar. 
3. You're now ready to go.